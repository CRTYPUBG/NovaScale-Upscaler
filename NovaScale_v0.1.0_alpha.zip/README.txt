NovaScale Alpha v0.1.0

- Windowed or borderless games only
- Do NOT use exclusive fullscreen
- Online games supported by design, use at your own risk
- No DLL injection
- No API hooking
